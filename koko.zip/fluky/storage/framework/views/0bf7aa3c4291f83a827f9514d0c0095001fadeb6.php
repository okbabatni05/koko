<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-body">
    <div class="row">
        <div class="col-sm-6">
            <div class="row">
                <div class="col-sm-12">
                    <?php echo e(__('URL')); ?>: <a href="<?php echo e($url); ?>" target="_blank"><?php echo e($url); ?></a>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <?php echo e(__('Status')); ?>: <span id="status" class="badge p-1">-</span>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12">
                    <button id="checkSignaling" class="btn btn-info mt-2"><?php echo e(__('Refresh')); ?></button>
                </div>
            </div>
        </div>
        <div class="col-sm-6">
            <h4><?php echo e(__('Troubleshooting')); ?></h4>
            <div class="callout callout-info">
                <ul>
                    <li><?php echo e(__('Make sure, the URL is correct')); ?></li>
                    <li><?php echo e(__('Make sure, the /server/.env file has been updated as per the documentation')); ?></li>
                    <li><?php echo e(__('Make sure, the NodeJS service is started as per the documentation')); ?></li>
                    <li><?php echo e(__('Make sure, the required ports are allowed in the Firewall as per the documentation')); ?></li>
                    <li><?php echo e(__('Make sure, the SSL certificates are valid')); ?></li>
                    <li><?php echo e(__('If you are using Cloudflare, make sure you use 8443 port')); ?></li>
                </ul>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script type="text/javascript">
    $("#checkSignaling").trigger('click');
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.1.0\resources\views/admin/signaling.blade.php ENDPATH**/ ?>