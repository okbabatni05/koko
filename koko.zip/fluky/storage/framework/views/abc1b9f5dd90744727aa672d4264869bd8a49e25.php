<?php $__env->startSection('template_title'); ?>
    <?php echo e(trans('installer_messages.environment.classic.templateTitle')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    <i class="fa fa-code fa-fw" aria-hidden="true"></i> <?php echo e(trans('installer_messages.environment.classic.title')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('container'); ?>

    <form method="post" action="<?php echo e(route('LaravelInstaller::environmentSaveClassic')); ?>">
        <?php echo csrf_field(); ?>

        <textarea class="textarea" name="envConfig" rows="12"><?php echo e($envConfig); ?></textarea>
        <div class="buttons buttons--right">
            <button class="button button--light" type="submit">
                <i class="fa fa-floppy-o fa-fw" aria-hidden="true"></i>
                <?php echo trans('installer_messages.environment.classic.save'); ?>

            </button>
        </div>
    </form>

    <?php if(session('checked')): ?>
        <div class="buttons-container">
            <a class="button float-right" href="<?php echo e(route('LaravelInstaller::database')); ?>">
                Install
                <i class="fa fa-angle-double-right fa-fw" aria-hidden="true"></i>
            </a>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.installer.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky_2.0.0_9_8\resources\views/vendor/installer/environment-classic.blade.php ENDPATH**/ ?>