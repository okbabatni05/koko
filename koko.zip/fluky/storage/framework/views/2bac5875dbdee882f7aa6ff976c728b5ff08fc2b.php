<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid text-center">
        <h1 class="mb-3"><?php echo e(__('Choose your plan')); ?></h1>
        <div class="container plan-selection">
            <div class="mb-3 ">
                <input type="radio" name="period" value="monthly" id="monthly" checked>
                <label for="monthly" class="btn"><?php echo e(__('Monthly')); ?></label>
                <input type="radio" name="period" value="yearly" id="yearly">
                <label for="yearly" class="btn"><?php echo e(__('Yearly')); ?></label>
            </div>
            <div class="card-deck text-center">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(getSetting('PRICING_PLAN_NAME_FREE')); ?>

                    </div>
                    <div class="card-body">
                        <?php if(auth()->user() && auth()->user()->plan_type == 'free'): ?>
                            <div class="ribbon-wrapper ribbon-lg">
                                <div class="ribbon bg-primary">
                                    <?php echo e(__('Current')); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <h3><?php echo e(__('Free')); ?></h3>
                        <ul class="list-unstyled mt-3 mb-4">
                            <?php $__currentLoopData = $freeFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($feature); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e(__('Report User')); ?></li>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(route('register')); ?>">
                            <button type="button" class="btn btn-secondary" <?php if(auth()->guard()->check()): ?> disabled
                                <?php endif; ?>><?php echo e(__('Join Now')); ?></button>
                        </a>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <?php echo e(getSetting('PRICING_PLAN_NAME_PAID')); ?>

                    </div>
                    <div class="card-body">
                        <?php if(auth()->user() && auth()->user()->plan_type == 'paid'): ?>
                            <div class="ribbon-wrapper ribbon-lg">
                                <div class="ribbon bg-primary">
                                    <?php echo e(__('Current')); ?>

                                </div>
                            </div>
                        <?php endif; ?>
                        <h3 id="montlyPrice"><?php echo e(getCurrencySymbol() . getSetting('MONTHLY_PRICE')); ?>

                            <small>/<?php echo e(__('month')); ?></small>
                        </h3>
                        <h3 id="yearlyPrice" hidden><?php echo e(getCurrencySymbol() . getSetting('YEARLY_PRICE')); ?>

                            <small>/<?php echo e(__('year')); ?></small>
                        </h3>
                        <ul class="list-unstyled mt-3 mb-4">
                            <li><?php echo e(__('All Basic Features')); ?></li>
                            <?php $__currentLoopData = $paidFeatures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($feature); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <div class="card-footer">
                        <form action="payment">
                            <input type="hidden" id="type" name="type" value="monthly">
                            <button type="submit" class="btn btn-theme"
                                <?php if(auth()->user() && auth()->user()->plan_type == 'paid'): ?> disabled <?php endif; ?>><?php echo e(__('Buy Now')); ?></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.1.0\resources\views/payment/pricing.blade.php ENDPATH**/ ?>