<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
      <table class="table table-bordered table-striped table-hover">
        <thead>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Plan Type</th>
          <th>Plan Status</th>
          <th>Status</th>
          <th>Created Date</th>
        </tr>
        </thead>
        <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($value->id); ?></td>
            <td><?php echo e($value->username); ?></td>
            <td><?php echo e($value->email); ?></td>
            <td>
              <?php if($value->gender == "male"): ?>
                <span class="badge badge-success">Male</span>
              <?php else: ?>
                <span class="badge badge-primary">Female</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($value->plan_type == "free"): ?>
                <span class="badge badge-info">Free</span>
              <?php else: ?>
                <span class="badge badge-success">Paid</span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($value->plan_status == "active"): ?>
                <span class="badge badge-success">Active</span>
              <?php elseif($value->plan_status == 'inactive'): ?>
                <span class="badge badge-info">Inactive</span>
              <?php else: ?>
                <span class="badge badge-danger">Expired</span>
              <?php endif; ?>
            </td>
            <td>
              <div class="custom-control custom-switch">
                <input type="checkbox" class="custom-control-input user-status" data-id="<?php echo e($value->id); ?>" id="customSwitch<?php echo e($value->id); ?>" <?php echo e($value->status == 'active' ? 'checked' : ''); ?>>
                <label class="custom-control-label" for="customSwitch<?php echo e($value->id); ?>"></label>
              </div>
            </td>
            <td><?php echo e($value->created_at); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
        <tr>
          <th>ID</th>
          <th>Username</th>
          <th>Email</th>
          <th>Gender</th>
          <th>Plan Type</th>
          <th>Plan Status</th>
          <th>Status</th>
          <th>Created Date</th>
        </tr>
        </tfoot>
      </table>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0\resources\views/admin/user/index.blade.php ENDPATH**/ ?>