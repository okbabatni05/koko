<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
<div class="card-body">
    <div class="row">
        <div class="col-sm-12">
            <div class="form-group">
                <button id="verifyLicense" class="btn btn-primary">Verify License</button>
                <button id="uninstallLicense" class="btn btn-danger">Uninstall License</button>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.0.0_9_8_13_08\resources\views/admin/license.blade.php ENDPATH**/ ?>