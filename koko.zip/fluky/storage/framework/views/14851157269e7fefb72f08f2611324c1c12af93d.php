<?php $__env->startSection('page', $page); ?>
<?php $__env->startSection('title', getSetting('APPLICATION_NAME') . ' | ' . $page); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <?php if($model->name): ?>
                <label><?php echo e($model->name . ' ('. $model->code . ')'); ?></label>
            <?php endif; ?>

            <form id="createUser">
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Code</label>
                            <input type="text" name="code" placeholder="Code" class="form-control" maxlength="64"
                                autofocus required>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Name</label>
                            <input type="text" name="name" placeholder="Name" class="form-control" maxlength="255"
                                required>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>RTL (Right to Left)</label>
                            <select id="rtl" class="form-control">
                                <option value="no" <?php if($model->rtl == 'no'): ?> selected <?php endif; ?>>No</option>
                                <option value="yes" <?php if($model->rtl == 'yes'): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Default</label>
                            <select id="default" class="form-control">
                                <option value="no" <?php if($model->default == 'no'): ?> selected <?php endif; ?>>No</option>
                                <option value="yes" <?php if($model->default == 'yes'): ?> selected <?php endif; ?>>Yes</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>Status</label>
                            <select id="status" class="form-control">
                                <option value="active" <?php if($model->status == 'active'): ?> selected <?php endif; ?>>Active</option>
                                <option value="inactive" <?php if($model->status == 'inactive'): ?> selected <?php endif; ?>>Inactive</option>
                            </select>
                        </div>
                    </div>

                    <div class="col-sm-6">
                        <div class="form-group">
                            <label>File</label>
                            <input type="file" id="file" class="form-control" accept=".json" required>
                        </div>
                    </div>
                </div>

                <button type="submit" id="save" class="btn btn-primary">Save</button>
                <a href="<?php echo e(route('languages')); ?>"><button type="button" class="btn btn-default">Cancel</button></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\fluky\fluky_2.1.0\resources\views/admin/language/form.blade.php ENDPATH**/ ?>